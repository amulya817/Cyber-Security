from dataclasses import dataclass
from typing import Dict, Any
import yaml

@dataclass
class ModelConfig:
    """Model configuration parameters."""
    state_dim: int = 100
    action_dim: int = 4
    learning_rate: float = 0.001
    gamma: float = 0.99
    epsilon: float = 1.0
    epsilon_min: float = 0.01
    epsilon_decay: float = 0.995
    memory_size: int = 10000
    batch_size: int = 64

@dataclass
class EnvironmentConfig:
    """Environment configuration parameters."""
    max_steps: int = 1000
    threat_threshold: float = 0.7
    reward_scale: float = 10.0

@dataclass
class TrainingConfig:
    """Training configuration parameters."""
    num_episodes: int = 1000
    target_update_frequency: int = 100
    eval_frequency: int = 50
    save_frequency: int = 100
    checkpoint_dir: str = "./checkpoints"

class Config:
    def __init__(self, config_path: str = None):
        """Initialize configuration with default values."""
        self.model = ModelConfig()
        self.env = EnvironmentConfig()
        self.training = TrainingConfig()
        
        if config_path:
            self.load_config(config_path)

    def load_config(self, config_path: str):
        """Load configuration from YAML file."""
        with open(config_path, 'r') as f:
            config_dict = yaml.safe_load(f)
            
        # Update configurations
        self._update_config(self.model, config_dict.get('model', {}))
        self._update_config(self.env, config_dict.get('environment', {}))
        self._update_config(self.training, config_dict.get('training', {}))

    @staticmethod
    def _update_config(config_obj: Any, config_dict: Dict):
        """Update configuration object with dictionary values."""
        for key, value in config_dict.items():
            if hasattr(config_obj, key):
                setattr(config_obj, key, value)

    def save_config(self, config_path: str):
        """Save configuration to YAML file."""
        config_dict = {
            'model': self.model.__dict__,
            'environment': self.env.__dict__,
            'training': self.training.__dict__
        }
        
        with open(config_path, 'w') as f:
            yaml.dump(config_dict, f)
