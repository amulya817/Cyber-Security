import logging
import sys
from typing import Optional

def setup_logger(name: Optional[str] = None) -> logging.Logger:
    """Setup and configure logger."""
    logger = logging.getLogger(name or __name__)
    
    if not logger.handlers:
        logger.setLevel(logging.INFO)

        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)

        # File handler
        file_handler = logging.FileHandler('cyber_threat_detection.log')
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger

class TrainingLogger:
    def __init__(self):
        """Initialize training logger."""
        self.logger = setup_logger('training')
        self.episode_rewards = []
        self.episode_losses = []

    def log_episode(self, 
                   episode: int,
                   reward: float,
                   loss: float,
                   epsilon: float):
        """Log episode information."""
        self.episode_rewards.append(reward)
        self.episode_losses.append(loss)
        
        self.logger.info(
            f"Episode {episode} - "
            f"Reward: {reward:.2f} - "
            f"Loss: {loss:.4f} - "
            f"Epsilon: {epsilon:.4f}"
        )

    def log_evaluation(self, 
                      episode: int,
                      metrics: dict):
        """Log evaluation metrics."""
        self.logger.info(
            f"Evaluation at episode {episode}:\n"
            f"Precision: {metrics['precision']:.4f}\n"
            f"Recall: {metrics['recall']:.4f}\n"
            f"F1 Score: {metrics['f1_score']:.4f}\n"
            f"Average Response Time: {metrics['avg_response_time']:.4f}ms"
        )

    def log_training_summary(self):
        """Log training summary statistics."""
        self.logger.info(
            f"Training Summary:\n"
            f"Total Episodes: {len(self.episode_rewards)}\n"
            f"Average Reward: {sum(self.episode_rewards)/len(self.episode_rewards):.2f}\n"
            f"Average Loss: {sum(self.episode_losses)/len(self.episode_losses):.4f}"
        )
