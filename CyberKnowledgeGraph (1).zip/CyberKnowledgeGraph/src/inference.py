import os
import numpy as np
from typing import Dict, Tuple
import time
from flask import Flask, request, jsonify
from flask_cors import CORS
from src.agent.rl_agent import RLAgent
from src.data.preprocessor import DataPreprocessor
from src.data.knowledge_graph import KnowledgeGraphConnector
from src.edge.optimizer import EdgeOptimizer
from src.utils.logger import setup_logger
from src.evaluation.metrics import EvaluationMetrics
from src.data.testbed_connector import TestbedConnector

# Initialize logger at module level with more verbose logging
logger = setup_logger(level="DEBUG")

# Initialize Flask app with proper configurations
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes
inference_system = None

def initialize_inference() -> bool:
    """Initialize the inference system."""
    global inference_system
    try:
        logger.debug("Starting inference system initialization...")

        # First check if checkpoints directory exists
        checkpoint_dir = "checkpoints"
        if not os.path.exists(checkpoint_dir):
            logger.error("Checkpoints directory not found")
            return False

        # Use model_final.pth for stable testing
        model_path = os.path.join(checkpoint_dir, "model_final.pth")
        if not os.path.exists(model_path):
            logger.error(f"Final model checkpoint not found at {model_path}")
            return False

        logger.info(f"Using model checkpoint: {model_path}")
        inference_system = ThreatDetectionInference(model_path=model_path)

        if inference_system is None:
            logger.error("Failed to initialize inference system")
            return False

        logger.info("Inference system initialized successfully")
        return True

    except Exception as e:
        logger.error(f"Error initializing inference system: {str(e)}")
        return False

class ThreatDetectionInference:
    def __init__(self, model_path: str):
        """Initialize inference components."""
        try:
            if not model_path:
                raise ValueError("Model path cannot be None")

            # Initialize components
            self.preprocessor = DataPreprocessor()
            self.metrics = EvaluationMetrics()

            # Initialize CSV-based knowledge graph connector
            csv_path = os.path.join("attached_assets", "export300.csv")
            if not os.path.exists(csv_path):
                raise FileNotFoundError(f"Knowledge graph data not found at {csv_path}")

            self.kg_connector = KnowledgeGraphConnector(csv_path=csv_path)

            # Initialize testbed connector
            # TODO: Get actual testbed URL from configuration
            self.testbed_connector = TestbedConnector(
                testbed_url="http://testbed.example.com",
                api_key=os.environ.get("TESTBED_API_KEY")
            )

            # Initialize agent with fixed dimensions
            self.agent = RLAgent(
                state_dim=8,  # Matches preprocessor's default feature names
                action_dim=4  # Four possible actions
            )

            # Load model weights
            if not os.path.exists(model_path):
                raise FileNotFoundError(f"Model checkpoint not found at {model_path}")

            self.agent.load_model(model_path)
            logger.info(f"Model loaded successfully from {model_path}")

            # Initialize edge optimizer
            self.edge_optimizer = EdgeOptimizer(self.agent.policy_net)
            self.edge_optimizer.optimize_for_edge()

            logger.info("Inference system initialized successfully")

        except Exception as e:
            logger.error(f"Error initializing inference system: {str(e)}")
            raise

    def preprocess_threat_data(self, raw_data: Dict) -> np.ndarray:
        """Preprocess incoming threat data with testbed integration."""
        try:
            # Get testbed threat indicators
            testbed_indicators = self.testbed_connector.get_threat_indicators()

            # Combine traditional threat data with testbed data
            enhanced_data = {
                **raw_data,
                **testbed_indicators
            }

            # Extract threat patterns
            threat_patterns = self.kg_connector.get_threat_patterns()

            # Process data using preprocessor
            cve_data = self.preprocessor.process_cve_data([enhanced_data])
            attack_data = self.preprocessor.process_attack_data(threat_patterns)

            # Create feature vector
            feature_vector = self.preprocessor.create_feature_vector(
                cve_data, attack_data
            )

            # Optimize for edge deployment
            return self.edge_optimizer.compress_state(feature_vector[0])

        except Exception as e:
            logger.error(f"Error preprocessing threat data: {str(e)}")
            raise

    def detect_threat(self, threat_data: Dict) -> Tuple[int, float, Dict]:
        """Perform threat detection and return action and confidence."""
        start_time = time.time()

        try:
            # Preprocess threat data
            state = self.preprocess_threat_data(threat_data)

            # Get action and confidence using edge-optimized inference
            action, confidence = self.edge_optimizer.optimize_inference(state)

            # Record response time
            response_time = (time.time() - start_time) * 1000  # Convert to ms
            self.metrics.record_response_time(response_time)

            # Prepare response
            response = {
                'action': action,
                'confidence': confidence,
                'response_time': response_time,
                'action_mapping': {
                    0: 'No Action Required',
                    1: 'Low-Level Response',
                    2: 'Medium-Level Response',
                    3: 'High-Level Response'
                }
            }

            logger.info(
                f"Threat detection completed - Action: {action}, "
                f"Confidence: {confidence:.4f}, "
                f"Response Time: {response_time:.2f}ms"
            )

            return action, confidence, response

        except Exception as e:
            logger.error(f"Error during threat detection: {str(e)}")
            raise

    def get_performance_metrics(self) -> Dict:
        """Get current performance metrics."""
        return self.metrics.calculate_metrics()

@app.route('/')
def root():
    """Root endpoint showing API documentation."""
    return """
    <html>
        <head>
            <title>6G Threat Detection API</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 40px; }
                .endpoint { margin: 20px 0; padding: 20px; background: #f5f5f5; border-radius: 5px; }
                h1 { color: #333; }
                h2 { color: #666; }
                code { background: #e0e0e0; padding: 2px 5px; border-radius: 3px; }
            </style>
        </head>
        <body>
            <h1>6G Network Threat Detection API</h1>
            <p>Welcome to the threat detection service. Use the following endpoints:</p>

            <div class="endpoint">
                <h2>Health Check</h2>
                <p>GET <code>/health</code></p>
                <p>Check if the service is running.</p>
            </div>

            <div class="endpoint">
                <h2>Threat Detection</h2>
                <p>POST <code>/detect</code></p>
                <p>Submit network data for threat analysis.</p>
            </div>

            <div class="endpoint">
                <h2>Performance Metrics</h2>
                <p>GET <code>/metrics</code></p>
                <p>View current system performance metrics.</p>
            </div>
        </body>
    </html>
    """

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint."""
    return jsonify({"status": "healthy"}), 200

@app.route('/detect', methods=['POST', 'OPTIONS'])
def detect_threat_api():
    """Endpoint for threat detection."""
    try:
        # Handle CORS preflight request
        if request.method == 'OPTIONS':
            return '', 204

        if not inference_system:
            logger.error("Inference system not initialized")
            return jsonify({"error": "Inference system not initialized"}), 500

        if not request.is_json:
            logger.error("Invalid content type")
            return jsonify({"error": "Content-Type must be application/json"}), 400

        threat_data = request.get_json()
        if not threat_data:
            logger.error("No threat data provided")
            return jsonify({"error": "No threat data provided"}), 400

        # Add debug logging
        logger.info(f"Received threat detection request with data: {threat_data}")

        action, confidence, response = inference_system.detect_threat(threat_data)

        # Log successful response
        logger.info(f"Threat detection successful: {response}")
        return jsonify(response), 200

    except Exception as e:
        logger.error(f"Error processing threat detection request: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/metrics', methods=['GET'])
def get_metrics_api():
    """Endpoint for retrieving performance metrics."""
    try:
        if not inference_system:
            return jsonify({"error": "Inference system not initialized"}), 500

        metrics = inference_system.get_performance_metrics()
        return jsonify(metrics), 200
    except Exception as e:
        logger.error(f"Error retrieving metrics: {str(e)}")
        return jsonify({"error": str(e)}), 500

def main():
    """Main function to run the Flask application."""
    try:
        logger.debug("Starting main function...")

        # Initialize the inference system before starting the Flask app
        if not initialize_inference():
            logger.error("Failed to initialize inference system")
            exit(1)

        # Get port from environment or use default
        port = int(os.environ.get('PORT', 5000))
        logger.info(f"Starting Flask app on port {port}")

        # Run the Flask app with proper configuration for Replit
        app.run(
            host='0.0.0.0',  # Allow external access
            port=port,       # Use configured port
            debug=False      # Disable debug mode for production
        )

    except Exception as e:
        logger.error(f"Error in main: {str(e)}")
        raise

if __name__ == "__main__":
    main()