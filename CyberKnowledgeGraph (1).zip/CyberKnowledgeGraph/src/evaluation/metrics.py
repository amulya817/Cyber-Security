import numpy as np
from typing import List, Dict
from sklearn.metrics import precision_score, recall_score, f1_score
import time

class EvaluationMetrics:
    def __init__(self):
        """Initialize evaluation metrics tracker."""
        self.true_positives = 0
        self.false_positives = 0
        self.false_negatives = 0
        self.response_times = []
        self.rewards_history = []
        self.precision = 0.0
        self.recall = 0.0
        self.f1 = 0.0

    def update_detection_metrics(self, 
                               y_true: List[int], 
                               y_pred: List[int]):
        """Update threat detection metrics."""
        self.precision = precision_score(y_true, y_pred, average='weighted')
        self.recall = recall_score(y_true, y_pred, average='weighted')
        self.f1 = f1_score(y_true, y_pred, average='weighted')

    def record_response_time(self, response_time: float):
        """Record response time for performance tracking."""
        self.response_times.append(response_time)

    def record_reward(self, reward: float):
        """Record reward for training evaluation."""
        self.rewards_history.append(reward)

    def calculate_metrics(self) -> Dict:
        """Calculate and return all evaluation metrics."""
        avg_response_time = np.mean(self.response_times) if self.response_times else 0
        avg_reward = np.mean(self.rewards_history) if self.rewards_history else 0

        return {
            'precision': self.precision,
            'recall': self.recall,
            'f1_score': self.f1,
            'avg_response_time': avg_response_time,
            'avg_reward': avg_reward,
            'total_episodes': len(self.rewards_history)
        }

    def reset(self):
        """Reset all metrics."""
        self.true_positives = 0
        self.false_positives = 0
        self.false_negatives = 0
        self.response_times = []
        self.rewards_history = []
        self.precision = 0.0
        self.recall = 0.0
        self.f1 = 0.0

class PerformanceMonitor:
    def __init__(self):
        """Initialize performance monitoring."""
        self.start_time = time.time()
        self.cpu_usage = []
        self.memory_usage = []

    def record_resource_usage(self, cpu_percent: float, memory_percent: float):
        """Record resource usage metrics."""
        self.cpu_usage.append(cpu_percent)
        self.memory_usage.append(memory_percent)

    def get_performance_metrics(self) -> Dict:
        """Calculate and return performance metrics."""
        return {
            'avg_cpu_usage': np.mean(self.cpu_usage),
            'avg_memory_usage': np.mean(self.memory_usage),
            'peak_cpu_usage': max(self.cpu_usage),
            'peak_memory_usage': max(self.memory_usage),
            'runtime': time.time() - self.start_time
        }