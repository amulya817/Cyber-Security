import pandas as pd
import logging
from typing import Dict, List, Any

class KnowledgeGraphConnector:
    def __init__(self, csv_path: str):
        """Initialize CSV-based data connector."""
        self.csv_path = csv_path
        self.logger = logging.getLogger(__name__)
        self.data = None
        self._load_data()

    def _load_data(self):
        """Load data from CSV file."""
        try:
            self.data = pd.read_csv(self.csv_path)
            self.logger.info(f"Successfully loaded {len(self.data)} records from CSV")
        except Exception as e:
            self.logger.error(f"Error loading CSV file: {str(e)}")
            self.data = pd.DataFrame()

    def get_threat_patterns(self) -> List[Dict[str, Any]]:
        """Retrieve threat patterns from CSV data."""
        if self.data is None or self.data.empty:
            self.logger.warning("No threat pattern data available")
            return []

        try:
            # Filter and process threat patterns
            threat_patterns = []
            for _, row in self.data.iterrows():
                if 'CVE' in str(row.get('n', '')):
                    pattern = {
                        'id': str(row.get('n', '')).split(':')[1] if ':' in str(row.get('n', '')) else '',
                        'type': 'CVE',
                        'description': str(row.get('description', '')),
                        'severity': str(row.get('severity', 'medium'))
                    }
                    threat_patterns.append(pattern)

            self.logger.info(f"Retrieved {len(threat_patterns)} threat patterns")
            return threat_patterns
        except Exception as e:
            self.logger.error(f"Error processing threat patterns: {str(e)}")
            return []

    def get_attack_techniques(self) -> List[Dict[str, Any]]:
        """Retrieve attack techniques from CSV data."""
        if self.data is None or self.data.empty:
            self.logger.warning("No attack technique data available")
            return []

        try:
            # Filter and process attack techniques
            techniques = []
            for _, row in self.data.iterrows():
                if any(t in str(row.get('n', '')) for t in ['CAPEC', 'CWE']):
                    technique = {
                        'id': str(row.get('n', '')).split(':')[1] if ':' in str(row.get('n', '')) else '',
                        'type': 'ATTACK',
                        'name': str(row.get('name', '')),
                        'related_entities': [str(row.get('m', ''))] if pd.notna(row.get('m')) else []
                    }
                    techniques.append(technique)

            self.logger.info(f"Retrieved {len(techniques)} attack techniques")
            return techniques
        except Exception as e:
            self.logger.error(f"Error processing attack techniques: {str(e)}")
            return []