import pandas as pd
import numpy as np
from typing import Dict, List, Any, Tuple
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from src.utils.logger import setup_logger
import re

logger = setup_logger()

class DataPreprocessor:
    def __init__(self):
        """Initialize data preprocessing components."""
        self.scaler = StandardScaler()
        self.encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')
        self.feature_columns = []
        self.entity_types = ['CVE', 'CWE', 'CAPEC', 'ICS', 'Mobile']
        self.is_fitted = False
        self.default_feature_names = [
            'severity_score',
            'attack_vector_network',
            'attack_vector_local',
            'cve_related',
            'cwe_related',
            'capec_related',
            'ics_related',
            'mobile_related'
        ]

    def _parse_neo4j_entity(self, entity_str: str) -> Dict:
        """Parse entity string format into a dictionary."""
        try:
            # Remove leading/trailing parentheses and :Entity
            cleaned_str = entity_str.strip('()').replace(':Entity', '')

            # Extract content within curly braces
            match = re.search(r'\{(.*?)\}', cleaned_str)
            if not match:
                return {}

            content = match.group(1)

            # Split by comma and create dictionary
            pairs = [pair.strip() for pair in content.split(',')]
            entity_dict = {}

            for pair in pairs:
                if ':' in pair:
                    key, value = pair.split(':', 1)
                    key = key.strip(' "\'')  # Remove quotes from keys
                    value = value.strip(' "\'')  # Remove quotes from values
                    entity_dict[key] = value

            return entity_dict

        except Exception as e:
            logger.error(f"Error parsing entity: {str(e)}")
            return {}

    def load_knowledge_graph(self, csv_path: str) -> Tuple[pd.DataFrame, Dict]:
        """Load and process knowledge graph data from CSV."""
        try:
            # Read CSV file
            df = pd.read_csv(csv_path)
            logger.info(f"Loaded CSV with {len(df)} rows")

            # Extract entities and relationships
            entities = {}
            relationships = []

            for _, row in df.iterrows():
                try:
                    # Parse entities using custom parser
                    source = self._parse_neo4j_entity(str(row['n']))
                    target = self._parse_neo4j_entity(str(row['m']))
                    relation = str(row['r']).strip('[]').strip("'")

                    if not source or not target:
                        continue

                    # Store entities with proper id handling
                    source_id = source.get('id', source.get('name', ''))
                    target_id = target.get('id', target.get('name', ''))

                    if source_id:
                        entities[source_id] = {
                            'name': source.get('name', ''),
                            'type': source.get('type', ''),
                            'attributes': source
                        }
                    if target_id:
                        entities[target_id] = {
                            'name': target.get('name', ''),
                            'type': target.get('type', ''),
                            'attributes': target
                        }

                    # Store relationships
                    relationships.append({
                        'source': source_id,
                        'target': target_id,
                        'relation': relation
                    })

                except Exception as e:
                    logger.warning(f"Error processing row: {e}")
                    continue

            logger.info(f"Processed {len(entities)} entities and {len(relationships)} relationships")
            return pd.DataFrame(relationships), entities

        except Exception as e:
            logger.error(f"Error loading knowledge graph: {str(e)}")
            # Return empty DataFrame and dict if loading fails
            return pd.DataFrame(), {}

    def process_cve_data(self, cve_data: List[Dict]) -> pd.DataFrame:
        """Process CVE data including relationships."""
        try:
            # If input is empty, create a default structure
            if not cve_data:
                logger.warning("No CVE data provided, using default structure")
                return pd.DataFrame({
                    'severity_score': [0],
                    'attack_vector_network': [0],
                    'attack_vector_local': [0]
                })

            # Convert list of dictionaries to DataFrame
            df = pd.DataFrame(cve_data)

            # Extract severity scores
            severity_map = {
                'high': 3,
                'medium': 2,
                'low': 1,
                'critical': 4,
                'none': 0
            }

            df['severity_score'] = df['severity'].map(severity_map).fillna(0)

            # Ensure attack vector features exist
            if 'attack_vector' not in df.columns:
                df['attack_vector'] = 'unknown'

            # Create one-hot encoded features with proper names
            attack_vectors = self.encoder.fit_transform(
                df[['attack_vector']].fillna('unknown')
            )
            attack_vector_names = [f'attack_vector_{name}' for name in 
                                    self.encoder.get_feature_names_out(['attack_vector'])]
            attack_vector_df = pd.DataFrame(
                attack_vectors,
                columns=attack_vector_names
            )

            # Combine features
            result_df = pd.concat([
                df[['severity_score']], 
                attack_vector_df
            ], axis=1)

            self.feature_columns.extend(result_df.columns)
            return result_df

        except Exception as e:
            logger.error(f"Error processing CVE data: {str(e)}")
            return pd.DataFrame({
                'severity_score': [0],
                'attack_vector_unknown': [1]
            })

    def process_attack_data(self, attack_data: List[Dict]) -> pd.DataFrame:
        """Process attack pattern data."""
        try:
            # If input is empty, create a default structure
            if not attack_data:
                logger.warning("No attack data provided, using default structure")
                return pd.DataFrame({
                    'technique_type': [0],
                    'technique_count': [0]
                })

            df = pd.DataFrame(attack_data)

            # Create features for each entity type
            for entity_type in self.entity_types:
                col_name = f'{entity_type.lower()}_related'
                df[col_name] = df.apply(
                    lambda x: 1 if entity_type in str(x.get('type', '')) 
                    else 0, 
                    axis=1
                )

            # Ensure numeric features and proper names
            feature_cols = [f'{entity_type.lower()}_related' for entity_type in self.entity_types]
            df['technique_count'] = df.apply(
                lambda x: len(str(x.get('type', '')).split(',')) if x.get('type') else 0,
                axis=1
            )
            feature_cols.append('technique_count')

            self.feature_columns.extend(feature_cols)
            return df[feature_cols]

        except Exception as e:
            logger.error(f"Error processing attack data: {str(e)}")
            return pd.DataFrame({
                'technique_type': [0],
                'technique_count': [0]
            })

    def _process_features(self, data: pd.DataFrame, feature_names: List[str]) -> pd.DataFrame:
        """Process features with consistent naming."""
        if data.empty:
            return pd.DataFrame(0, index=[0], columns=feature_names)

        # Ensure all expected columns exist
        for col in feature_names:
            if col not in data.columns:
                data[col] = 0

        return data[feature_names]

    def create_feature_vector(self, 
                           cve_data: pd.DataFrame, 
                           attack_data: pd.DataFrame) -> np.ndarray:
        """Create feature vector with proper feature names."""
        try:
            # Ensure consistent feature names
            self.feature_columns = self.default_feature_names

            # Process features with consistent naming
            cve_features = self._process_features(cve_data, 
                ['severity_score', 'attack_vector_network', 'attack_vector_local'])

            attack_features = self._process_features(attack_data,
                ['cve_related', 'cwe_related', 'capec_related', 'ics_related', 'mobile_related'])

            # Combine features
            combined_features = pd.concat([cve_features, attack_features], axis=1)
            combined_features = combined_features.fillna(0)

            # Ensure columns are in consistent order
            combined_features = combined_features[self.feature_columns]

            # Fit scaler if not already fitted
            if not self.is_fitted:
                self.scaler.fit(combined_features)
                self.is_fitted = True

            # Transform data
            scaled_features = self.scaler.transform(combined_features)
            return scaled_features

        except Exception as e:
            logger.error(f"Error creating feature vector: {str(e)}")
            # Return zero vector with correct dimension
            return np.zeros((1, len(self.default_feature_names)))

    def normalize_state(self, state: np.ndarray) -> np.ndarray:
        """Normalize state vector for RL input."""
        try:
            if state.size == 0:
                logger.warning("Empty state vector, using default")
                return np.zeros(len(self.default_feature_names))

            # Ensure state is 2D for scaler
            if state.ndim == 1:
                state = state.reshape(1, -1)

            # Create DataFrame with consistent feature names
            state_df = pd.DataFrame(
                state, 
                columns=self.default_feature_names[:state.shape[1]]
            )

            # Transform with feature names
            return self.scaler.transform(state_df).flatten()

        except Exception as e:
            logger.error(f"Error normalizing state: {str(e)}")
            return np.zeros(len(self.default_feature_names))

    def create_edge_optimized_features(self, 
                                     feature_vector: np.ndarray) -> np.ndarray:
        """Create optimized feature representation for edge deployment."""
        try:
            if feature_vector.size == 0:
                logger.warning("Empty feature vector, using default")
                return np.zeros((1, 7))

            # Use all available features but ensure consistent dimensionality
            return feature_vector[:, :min(feature_vector.shape[1], 7)]
        except Exception as e:
            logger.error(f"Error optimizing features: {str(e)}")
            return np.zeros((1, 7))