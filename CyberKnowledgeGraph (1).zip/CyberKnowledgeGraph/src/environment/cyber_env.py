import gymnasium as gym
import numpy as np
from typing import Tuple, Dict, Any
from gymnasium import spaces
from src.environment.reward import RewardCalculator
from src.data.preprocessor import DataPreprocessor

class CyberThreatEnv(gym.Env):
    """Custom Gymnasium environment for cyber threat detection."""

    def __init__(self, feature_dim: int, preprocessor: DataPreprocessor):
        super(CyberThreatEnv, self).__init__()

        # Define action and observation spaces
        self.action_space = spaces.Discrete(4)  # Different threat response levels
        self.observation_space = spaces.Box(
            low=-5.0, high=5.0, shape=(feature_dim,), dtype=np.float32
        )

        self.preprocessor = preprocessor
        self.reward_calculator = RewardCalculator()
        self.current_state = None
        self.episode_step = 0
        self.max_steps = 1000

    def reset(self, seed=None) -> Tuple[np.ndarray, Dict]:
        """Reset environment to initial state."""
        super().reset(seed=seed)
        self.episode_step = 0

        # Initialize state with clipped normal distribution
        self.current_state = np.clip(
            np.random.normal(0, 1, self.observation_space.shape),
            -5.0, 5.0
        ).astype(np.float32)
        return self.current_state, {}

    def step(self, action: int) -> Tuple[np.ndarray, float, bool, bool, Dict]:
        """Execute one environment step."""
        self.episode_step += 1

        # Simulate threat evolution
        next_state = self._evolve_threat_state(self.current_state, action)

        # Calculate reward based on action and state transition
        reward = self.reward_calculator.calculate_reward(
            self.current_state, next_state, action
        )

        # Clip reward for stability
        reward = np.clip(reward, -10.0, 10.0)

        # Check if episode is done
        done = self.episode_step >= self.max_steps

        self.current_state = next_state
        return next_state, float(reward), done, False, {}

    def _evolve_threat_state(self, 
                           current_state: np.ndarray, 
                           action: int) -> np.ndarray:
        """Simulate threat state evolution based on action."""
        # Add controlled noise to state evolution
        noise = np.clip(
            np.random.normal(0, 0.1, current_state.shape),
            -0.5, 0.5
        )

        # Action impact on state
        action_impact = np.zeros_like(current_state)
        if action == 0:  # No action
            action_impact += 0.1  # Slight increase in threat
        elif action == 1:  # Low-level response
            action_impact -= 0.05
        elif action == 2:  # Medium-level response
            action_impact -= 0.1
        elif action == 3:  # High-level response
            action_impact -= 0.2

        # Evolve state with controlled bounds
        new_state = np.clip(
            current_state + action_impact + noise,
            -5.0, 5.0
        ).astype(np.float32)

        return self.preprocessor.normalize_state(new_state)

    def render(self):
        """Render the environment."""
        pass  # Implement if visualization is needed