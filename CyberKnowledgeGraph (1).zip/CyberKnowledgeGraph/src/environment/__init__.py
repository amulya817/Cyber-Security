# Initialize environment package
