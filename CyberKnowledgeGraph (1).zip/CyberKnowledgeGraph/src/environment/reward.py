import numpy as np
from typing import Tuple

class RewardCalculator:
    """Calculate rewards for the RL agent's actions."""

    def __init__(self):
        """Initialize reward calculation parameters."""
        self.threat_threshold = 0.7
        self.action_costs = {
            0: 0.0,    # No action
            1: -0.05,  # Reduced penalty for low-level response
            2: -0.1,   # Reduced penalty for medium-level response
            3: -0.2    # Reduced penalty for high-level response
        }

    def calculate_reward(self, 
                        current_state: np.ndarray, 
                        next_state: np.ndarray, 
                        action: int) -> float:
        """Calculate reward based on state transition and action taken."""
        # Calculate threat level change
        current_threat = self._calculate_threat_level(current_state)
        next_threat = self._calculate_threat_level(next_state)
        threat_change = current_threat - next_threat

        # Scale the base reward to be more reasonable
        reward = threat_change * 5.0  # Reduced multiplier

        # Penalize unnecessary high-level actions
        if action > 1 and current_threat < self.threat_threshold:
            reward -= 1.0  # Reduced penalty

        # Add action cost
        reward += self.action_costs[action]

        # Additional reward for maintaining safe state
        if next_threat < self.threat_threshold:
            reward += 0.2  # Small positive reward for keeping system safe

        return float(reward)

    def _calculate_threat_level(self, state: np.ndarray) -> float:
        """Calculate overall threat level from state vector."""
        # Use mean of positive values as threat indicator
        positive_features = np.maximum(state, 0)
        # Add small epsilon to avoid division by zero
        return float(np.mean(positive_features) + 1e-6)

    def get_action_cost(self, action: int) -> float:
        """Get the cost associated with an action."""
        return self.action_costs[action]