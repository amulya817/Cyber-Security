import os
from typing import Tuple
import torch
import numpy as np
from src.data.knowledge_graph import KnowledgeGraphConnector
from src.data.preprocessor import DataPreprocessor
from src.environment.cyber_env import CyberThreatEnv
from src.agent.rl_agent import RLAgent
from src.evaluation.metrics import EvaluationMetrics, PerformanceMonitor
from src.utils.logger import setup_logger

# Initialize logger at module level
logger = setup_logger()

def setup_training_environment() -> Tuple[CyberThreatEnv, RLAgent, DataPreprocessor]:
    """Setup training environment and components."""
    try:
        logger.info("Starting training environment setup...")

        # Initialize preprocessor
        preprocessor = DataPreprocessor()
        csv_path = os.path.join("attached_assets", "export300.csv")

        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"CSV file not found at {csv_path}")

        logger.info(f"Loading data from CSV: {csv_path}")

        # Initialize CSV-based data connector
        kg_connector = KnowledgeGraphConnector(csv_path=csv_path)

        # Get threat data
        threat_patterns = kg_connector.get_threat_patterns()
        attack_techniques = kg_connector.get_attack_techniques()

        logger.info(f"Retrieved {len(threat_patterns)} threat patterns and "
                   f"{len(attack_techniques)} attack techniques")

        # Process data
        logger.info("Processing CVE data...")
        cve_data = preprocessor.process_cve_data(threat_patterns)

        logger.info("Processing attack data...")
        attack_data = preprocessor.process_attack_data(attack_techniques)

        logger.info("Creating feature vector...")
        feature_vector = preprocessor.create_feature_vector(cve_data, attack_data)

        if feature_vector.size == 0:
            logger.warning("Empty feature vector, using default dimensions")
            feature_vector = np.zeros((1, 10))  # Default 10-dimensional feature space

        feature_dim = feature_vector.shape[1]
        logger.info(f"Feature vector dimension: {feature_dim}")

        # Setup environment
        logger.info("Initializing environment...")
        env = CyberThreatEnv(
            feature_dim=feature_dim,
            preprocessor=preprocessor
        )

        # Initialize agent
        logger.info("Initializing RL agent...")
        agent = RLAgent(
            state_dim=feature_dim,
            action_dim=env.action_space.n,
            learning_rate=0.001,
            gamma=0.99,
            epsilon=1.0,
            epsilon_min=0.01,
            epsilon_decay=0.995,
            memory_size=10000,
            batch_size=64
        )

        logger.info("Training environment setup completed successfully")
        return env, agent, preprocessor

    except Exception as e:
        logger.error(f"Error setting up training environment: {str(e)}")
        raise

def main():
    """Main training function."""
    try:
        logger.info("Starting main training process...")

        # Setup environment and components
        env, agent, preprocessor = setup_training_environment()
        metrics = EvaluationMetrics()
        performance_monitor = PerformanceMonitor()

        # Training loop
        num_episodes = 100  # Start with a small number for testing
        max_steps = 1000

        logger.info(f"Beginning training loop with {num_episodes} episodes...")

        # Track metrics per episode
        episode_rewards = []
        episode_losses = []
        action_counts = {i: 0 for i in range(env.action_space.n)}

        for episode in range(num_episodes):
            try:
                state, _ = env.reset()
                episode_reward = 0
                episode_loss = 0
                step_count = 0

                for step in range(max_steps):
                    # Select and perform action
                    action = agent.select_action(state)
                    action_counts[action] += 1

                    next_state, reward, done, _, _ = env.step(action)

                    # Store transition and train
                    agent.store_transition(state, action, reward, next_state, done)
                    loss = agent.train()

                    if loss is not None:
                        episode_loss += loss
                        metrics.record_reward(reward)

                    episode_reward += reward
                    step_count += 1
                    state = next_state

                    if done:
                        break

                # Calculate averages
                avg_loss = episode_loss / step_count if step_count > 0 else 0
                episode_rewards.append(episode_reward)
                episode_losses.append(avg_loss)

                # Log progress every episode
                logger.info(
                    f"Episode {episode + 1}/{num_episodes} - "
                    f"Reward: {episode_reward:.2f} - "
                    f"Avg Loss: {avg_loss:.4f} - "
                    f"Steps: {step_count} - "
                    f"Epsilon: {agent.epsilon:.3f}"
                )

                # Log detailed metrics every 10 episodes
                if (episode + 1) % 10 == 0:
                    logger.info("=" * 50)
                    logger.info(f"Detailed Metrics at Episode {episode + 1}")
                    logger.info("=" * 50)

                    # Calculate metrics over last 10 episodes
                    recent_rewards = episode_rewards[-10:]
                    recent_losses = episode_losses[-10:]

                    reward_mean = np.mean(recent_rewards)
                    reward_std = np.std(recent_rewards)
                    loss_mean = np.mean(recent_losses)
                    loss_std = np.std(recent_losses)

                    # Log action distribution
                    total_actions = sum(action_counts.values())
                    action_dist = {k: v/total_actions for k, v in action_counts.items()}

                    logger.info(f"Last 10 Episodes - Reward Mean: {reward_mean:.2f}, Std: {reward_std:.2f}")
                    logger.info(f"Last 10 Episodes - Loss Mean: {loss_mean:.4f}, Std: {loss_std:.4f}")
                    logger.info(f"Action Distribution: {action_dist}")
                    logger.info(f"Current Epsilon: {agent.epsilon:.4f}")
                    logger.info("=" * 50)

                # Update target network periodically
                if episode % 10 == 0:
                    agent.update_target_network()
                    logger.info(f"Updated target network at episode {episode + 1}")

                # Save model checkpoint
                if (episode + 1) % 25 == 0:
                    save_path = os.path.join("checkpoints", f"model_episode_{episode+1}.pth")
                    os.makedirs("checkpoints", exist_ok=True)
                    agent.save_model(save_path)
                    logger.info(f"Saved model checkpoint to {save_path}")

            except Exception as e:
                logger.error(f"Error in episode {episode + 1}: {str(e)}")
                continue

        # Save final model
        final_save_path = os.path.join("checkpoints", "model_final.pth")
        agent.save_model(final_save_path)
        logger.info(f"Training completed. Final model saved to {final_save_path}")

        # Log final metrics
        logger.info("Final Training Metrics:")
        logger.info(f"Average Reward: {np.mean(episode_rewards):.2f}")
        logger.info(f"Average Loss: {np.mean(episode_losses):.4f}")
        logger.info(f"Final Action Distribution: {action_counts}")

    except Exception as e:
        logger.error(f"Training error: {str(e)}")
        raise

if __name__ == "__main__":
    main()