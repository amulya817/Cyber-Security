# Initialize edge package
